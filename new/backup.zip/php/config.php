<?
define('DSN', 'mysql:dbname=t_anketa;host=127.0.0.1');
define('USER', 'tech_curp');
define('PASSWORD', 'Gha9NhmLTfyv');
?>